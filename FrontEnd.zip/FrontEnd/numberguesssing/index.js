/*
const inputEl = document.querySelector("input");
const guessEl = document.querySelector(".guess");
const checkBtnEl = document.querySelector("button");
const remainingChancesTextEl = document.querySelector(".chances");
const remainingChancesEl = document.querySelector(".chance");

let randomNumber = Math.floor(Math.random() * 100) + 1; 
let totalChances = 10;

checkBtnEl.addEventListener("click", () => {
    totalChances--;
    const inputValue = parseInt(inputEl.value, 10);

    if (isNaN(inputValue) || inputValue < 1 || inputValue > 100) {
        guessEl.textContent = "Your number is invalid. Please enter a number between 1 and 100.";
        guessEl.style.color = "red";
        totalChances++; 
        return;
    }

    if (totalChances === 0 && inputValue !== randomNumber) {
        inputEl.value = "";
        inputEl.disabled = true;
        guessEl.textContent = "Oops...! Bad luck😥, You lost the game.";
        guessEl.style.color = "red";
        checkBtnEl.textContent = "Play Again...😉";
        remainingChancesTextEl.textContent = "No chances left";
        return;
    }

    if (inputValue === randomNumber) {
        guessEl.textContent = "🎉 Congratulations! You guessed the number.";
        guessEl.style.color = "green";
        inputEl.disabled = true;
        checkBtnEl.textContent = "Play Again...😉";
        return;
    } else if (inputValue > randomNumber) {
        guessEl.textContent = "Your Guess is High👍.";
        guessEl.style.color = "#1446a0";
    } else {
        guessEl.textContent = "Your Guess is Low👎.";
        guessEl.style.color = "#1446a0";
    }

    remainingChancesEl.textContent = totalChances;

    if (totalChances === 0) {
        inputEl.disabled = true;
        guessEl.textContent = `Game over! The correct number was ${randomNumber}.`;
        guessEl.style.color = "red";
        checkBtnEl.textContent = "Play Again...😉";
    }
});
*/
const inputEl = document.querySelector("input");
const guessEl = document.querySelector(".guess");
const checkBtnEl = document.querySelector("button");
const remainingChancesTextEl = document.querySelector(".chances");
const remainingChancesEl = document.querySelector(".chance");

let randomNumber = Math.floor(Math.random() * 100) + 1;
let totalChances = 10;
remainingChancesEl.textContent = totalChances;
checkBtnEl.addEventListener("click", () => {
    const inputValue = parseInt(inputEl.value, 10); 

    if (isNaN(inputValue) || inputValue < 1 || inputValue > 100) {
        guessEl.textContent = "Invalid input! Enter a number between 1 and 100.";
        guessEl.style.color = "red";
        return;
    }
    if (inputValue === randomNumber) {
        guessEl.textContent = "🎉 Congratulations! You guessed the correct number.";
        guessEl.style.color = "green";
        inputEl.disabled = true;
        checkBtnEl.textContent = "Play Again";
        return;
    }
    totalChances--;
    remainingChancesEl.textContent = totalChances;

    if (totalChances === 0) {
        inputEl.disabled = true;
        guessEl.textContent = `😥 Game over! The correct number was ${randomNumber}.`;
        guessEl.style.color = "red";
        checkBtnEl.textContent = "Play Again";
        return;
    }

    if (inputValue > randomNumber) {
        guessEl.textContent = "Your guess is too high. Try again!";
        guessEl.style.color = "#1446a0";
    } else {
        guessEl.textContent = "Your guess is too low. Try again!";
        guessEl.style.color = "#1446a0";
    }
});

// Event listener to restart the game when "Play Again" is clicked
checkBtnEl.addEventListener("click", () => {
    if (checkBtnEl.textContent === "Play Again") {
        randomNumber = Math.floor(Math.random() * 100) + 1; // Reset random number
        totalChances = 10; // Reset chances
        remainingChancesEl.textContent = totalChances; // Update UI
        inputEl.disabled = false;
        inputEl.value = ""; // Clear input field
        guessEl.textContent = ""; // Clear guess message
        checkBtnEl.textContent = "Check"; // Reset button text
    }
});

