// const choices=["rock","paper","scissor"];
// const player=document.getElementById("player");
// const computer=document.getElementById("computer");
// const result=document.getElementById("result");
// function playGame(playerChoice){
//     const computerChoice=choices[Math.floor(Math.random()*3)];
//     let result="";
//     if(playerChoice===computerChoice){
//         result="IT'S A TIE!";
//     }
//     else{
//         switch(playerChoice){
//             case "rock":
//                result= (computerChoice==="scissor")?"YOU WIN!":"YOU LOSE!";
//                 break;
//             case "paper":
//                 result=(computerChoice==="rock")?"YOU WIN!":"YOU LOSE!";
//                 break;
//             case "scissor":
//                 result=(computerChoice==="paper")?"YOU WIN!":"YOU LOSE!";
//                 break;
//         }   
//     }
//     player.textContent=`PLAYER: ${player}`;
//     computer.textContent=`COMPUTER: ${computer}`;
//     result.textContent=`${result}`;
// }
const choices = ["rock", "paper", "scissor"];
const player = document.getElementById("player");
const computer = document.getElementById("computer");
const result = document.getElementById("result");

function playGame(playerChoice) {
    const computerChoice = choices[Math.floor(Math.random() * 3)];
    let outcome = "";

    if (playerChoice === computerChoice) {
        outcome = "IT'S A TIE!😊";
    } else {
        switch (playerChoice) {
            case "rock":
                outcome = (computerChoice === "scissor") ? "YOU WIN!🏆" : "YOU LOSE!🥲";
                break;
            case "paper":
                outcome = (computerChoice === "rock") ? "YOU WIN!" : "YOU LOSE!";
                break;
            case "scissor":
                outcome = (computerChoice === "paper") ? "YOU WIN!" : "YOU LOSE!";
                break;
        }
    }

    player.textContent = `PLAYER: ${playerChoice.toUpperCase()}`;
    computer.textContent = `COMPUTER: ${computerChoice.toUpperCase()}`;
    result.textContent = outcome;
}
